/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.GA=function(){"use strict";function e(){!function(e,t,a,n,c,s,i){e.GoogleAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments)},e[c].l=1*new Date,s=t.createElement(a),i=t.getElementsByTagName(a)[0],s.async=1,s.src=n,i.parentNode.insertBefore(s,i)}(window,document,"script","https://www.google-analytics.com/analytics.js","ga"),ga("create",t,"auto"),ga("set","checkProtocolTask",function(){}),ga("require","displayfeatures")}const t="UA-61314754-3",a={cat:"extension",act:"installed"},n={cat:"extension",act:"updated"},c={cat:"message",act:"sent"},s={cat:"message",act:"received"},i={cat:"register",act:"registered"},o={cat:"register",act:"unregistered"};return window.addEventListener("load",e),{INSTALLED:a,UPDATED:n,SENT:c,RECEIVED:s,REGISTERED:i,UNREGISTERED:o,page:function(e){e&&ga("send","pageview",e)},event:function(e){e&&ga("send","event",e.cat,e.act)}}}();