/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.CB=function(){"use strict";function e(e){!e.remote&&app.Utils.isAutoSend()&&app.Msg.sendClipItem(e).catch(e=>{app.Gae.sendMessageFailed(e)})}function t(){app.Utils.isMonitorClipboard()&&setTimeout(function(){const t=app.CB.getTextFromClipboard();app.Utils.isWhiteSpace(t)||app.ClipItem.add(t,Date.now(),!1,!1,app.Device.myName()).then(t=>{e(t)}).catch(e=>{})},n)}function o(o,n,p){let a=!1;if("copiedToClipboard"===o.message)t();else if("copyToClipboard"===o.message){const t=o.clipItem,n=new app.ClipItem(t.text,t.lastSeen,t.fav,t.remote,t.device);app.CB.copyToClipboard(n.text),e(n)}return a}const n=250;return chrome.runtime.onMessage.addListener(o),{getTextFromClipboard:function(){const e=document.createElement("textArea");document.body.appendChild(e),e.focus(),e.select(),document.execCommand("Paste");const t=e.value;return e.remove(),t},copyToClipboard:function(e){const t=document.createElement("textArea");document.body.appendChild(t),t.textContent=e,t.focus(),t.select(),document.execCommand("Copy"),t.remove()}}}();