/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.User=function(){"use strict";function e(e,n){const t=app.Utils.get("uid");app.Utils.isSignedIn()&&!n&&e.id==t&&(app.Utils.set("needsCleanup",!0),app.Utils.set("signedIn",!1),app.Utils.set("registered",!1),app.Utils.set("cleanupRegToken",app.Utils.get("regToken")),app.Fb.signOut()),app.User.setInfo().catch(e=>{})}const n="Already signed in";return chrome.identity.onSignInChanged.addListener(e),{signIn:function(){return app.Utils.isSignedIn()?Promise.reject(new Error(n)):app.User.getAuthToken(!0).then(e=>{return app.Fb.signIn(e)}).then(e=>{return app.Utils.set("signedIn",!0),app.Utils.isWhiteSpace(e.photoURL)||app.Utils.set("photoURL",e.photoURL),Promise.resolve()})},signOut:function(){return app.Utils.isSignedIn()?app.Fb.signOut().then(()=>{return app.Utils.set("signedIn",!1),app.Utils.set("photoURL",""),Promise.resolve()}):Promise.resolve()},addAccess:function(){function e(){return app.Utils.get("needsCleanup")?(app.Utils.set("needsCleanup",!1),app.User.cleanup()):Promise.resolve()}return e().then(()=>{return app.User.signIn()}).then(()=>{return app.Reg.register()}).then(()=>{return app.Msg.sendDeviceAdded()})},removeAccess:function(){return app.Msg.sendDeviceRemoved().then(()=>{return app.Reg.unregister()}).then(()=>{return app.User.signOut()}).then(()=>{return app.Devices.clear(),Promise.resolve()})},getAuthToken:function(e){const n=!app.Utils.isSignedIn(),t=new ChromePromise;return t.identity.getAuthToken({interactive:n}).then(n=>{if(chrome.runtime.lastError){const t=chrome.runtime.lastError.message;if(e&&t&&n)return app.User.removeCachedAuthToken(n).then(()=>{return app.User.getAuthToken(!1)});throw new Error(t)}return Promise.resolve(n)})},cleanup:function(){return app.User.getAuthToken(!1).then(e=>{return app.User.removeCachedAuthToken(e)})},removeCachedAuthToken:function(e){const n=new ChromePromise;return n.identity.removeCachedAuthToken({token:e})},setInfo:function(){const e=new ChromePromise;return e.identity.getProfileUserInfo().then(e=>{return app.Utils.set("lastUid",app.Utils.get("uid")),app.Utils.set("lastEmail",app.Utils.get("email")),app.Utils.set("email",e.email),app.Utils.set("uid",e.id),Promise.resolve()})}}}();