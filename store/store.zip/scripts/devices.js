/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Devices=function(){"use strict";function e(e){let n=Object.create(null);for(let[i,t]of e)n[i]=t;return n}function n(){a=new Map;const e=app.Utils.get("devices");if(e)for(let n in e)if(e.hasOwnProperty(n)){let i=e[n],t=new app.Device(i.model,i.sn,i.os,i.nickname,i.lastSeen);a.set(n,t)}}function i(){app.Utils.set("devices",e(a)),chrome.runtime.sendMessage({message:"devicesChanged"},e=>{})}function t(){n()}function s(e,n,i){let t=!1;return"removeDevice"===e.message?app.Devices.removeByName(e.deviceName):"ping"===e.message&&app.Msg.sendPing().catch(e=>{app.Gae.sendMessageFailed(e)}),t}let a=new Map;return window.addEventListener("load",t),chrome.runtime.onMessage.addListener(s),{entries:function(){return a.entries()},add:function(e){a.set(e.getUniqueName(),e),i()},remove:function(e){this.removeByName(e.getUniqueName())},removeByName:function(e){a.delete(e),i()},clear:function(){a.clear(),i()}}}();