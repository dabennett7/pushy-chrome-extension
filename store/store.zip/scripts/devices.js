/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Devices=function(){"use strict";function e(e){let n=Object.create(null);for(let[t,i]of e)n[t]=i;return n}function n(){o=new Map;const e=app.Utils.get("devices");if(e)for(let n in e)if(e.hasOwnProperty(n)){let t=e[n],i=new app.Device(t.model,t.sn,t.os,t.nickname,t.lastSeen);o.set(n,i)}}function t(){app.Utils.set("devices",e(o)),chrome.runtime.sendMessage({message:"devicesChanged"},e=>{})}function i(){n()}let o=new Map;return window.addEventListener("load",i),{entries:function(){return o.entries()},add:function(e){o.set(e.getUniqueName(),e),t()},remove:function(e){this.removeByName(e.getUniqueName())},removeByName:function(e){o.delete(e),t()},clear:function(){o.clear(),t()}}}();