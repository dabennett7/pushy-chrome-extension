/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Notify=function(){"use strict";function e(e){let t="";return e.act===app.Msg.ACTION_MESSAGE?t=i:e.act===app.Msg.ACTION_DEVICE_ADDED?t=n:e.act===app.Msg.ACTION_DEVICE_REMOVED&&(t=c),t}const t="CLIP_MAN_SEND",i="/images/ic_local_copy.png",n="/images/ic_add_device.png",c="/images/ic_remove_device.png";return{NOTIFY_SEND:t,create:function(i,n){const c={type:"basic",title:"Pushy",isClickable:!0,eventTime:Date.now()},o=e(n);o&&chrome.notifications.getPermissionLevel(function(e){if("granted"===e)switch(i){case t:c.iconUrl=chrome.runtime.getURL(o),c.title="Sent push message",c.message=n.m,chrome.notifications.create(i,c,()=>{})}})},onSend:function(){const e=app.Utils.get("notify"),t=app.Utils.get("notifyOnSend");return e&&t}}}();