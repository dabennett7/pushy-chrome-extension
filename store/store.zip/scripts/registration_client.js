/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Reg=function(){"use strict";function e(e,t){return app.User.getAuthToken(!0).then(t=>{return app.Gae.doPost(e,t,!0)}).then(()=>{return Promise.resolve()}).catch(e=>{throw new Error(t+e)})}const t=`${app.Gae.GAE_ROOT}/registration/v1/`,r="Failed to register with the server.\n",n="Failed to unregister with the server.\n";return{register:function(){return app.Utils.isRegistered()||!app.Utils.allowReceive()?Promise.resolve():app.Fb.getRegToken().then(n=>{const i=`${t}register/${n}`;return e(i,r)}).then(()=>{return app.Utils.set("registered",!0),Promise.resolve()})},unregister:function(){return app.Utils.notRegistered()?Promise.resolve():app.Fb.getRegToken().then(r=>{const i=`${t}unregister/${r}`;return e(i,n)}).then(()=>{return app.Utils.set("registered",!1),Promise.resolve()})}}}();