/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.SW=function(){"use strict";function e(){return navigator.serviceWorker.register(u).then(e=>{return s=e,Promise.resolve(s)}).catch(e=>{return Promise.reject(new Error(n+e.message))})}function r(){return s.pushManager.getSubscription().then(e=>{return e?e.unsubscribe():Promise.reject(new Error("Not subscribed"))})}const n="Failed to register Service Worker: ",t="Failed to unregister Service Worker: ",i="Not registered ",o="returned false",u="../scripts/sw.js";let s=null;return{initialize:function(){return s?Promise.resolve():e().then(e=>{return app.Fb.initialize(e)}).then(()=>{return Promise.resolve()}).catch(e=>{return Promise.reject(new Error(n+e.message))})},unregister:function(){return s?r().then(()=>{return s.unregister()}).then(e=>{if(e)return s=null,Promise.resolve();throw new Error(o)}).catch(e=>{return Promise.reject(new Error(t+e.message))}):Promise.reject(new Error(t+i))},update:function(){return s&&s.update(),Promise.resolve()}}}();