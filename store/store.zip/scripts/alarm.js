/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Alarm=function(){"use strict";function e(e){"storage"===e.name&&app.Alarm.deleteOldClipItems()}function t(e){"storageDuration"===e.key&&app.Alarm.updateAlarms()}const a="storage";return chrome.alarms.onAlarm.addListener(e),addEventListener("storage",t,!1),{updateAlarms:function(){const e=app.Utils.getInt("storageDuration");4===e?chrome.alarms.clear(a):chrome.alarms.get(a,e=>{e||chrome.alarms.create(a,{when:Date.now()+app.Utils.MILLIS_IN_DAY,periodInMinutes:app.Utils.MIN_IN_DAY})})},deleteOldClipItems:function(){app.ClipItem.deleteOld().catch(e=>{})}}}();