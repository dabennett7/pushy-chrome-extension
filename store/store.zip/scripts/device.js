/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
!function(e){"use strict";const t=function(e,t,n,i,s){this.model=e,this.sn=t,this.os=n,this.nickname=i,s?this.lastSeen=s:this.lastSeen=Date.now()};t.MODEL="dM",t.SN="dSN",t.OS="dOS",t.NICKNAME="dN",t.prototype.getUniqueName=function(){return`${this.model} - ${this.sn} - ${this.os}`},t.prototype.getName=function(){let e=this.nickname;return app.Utils.isWhiteSpace(e)&&(e=this.getUniqueName()),e},t.prototype.isMe=function(){return this.getUniqueName()===t.myUniqueName()},t.myUniqueName=function(){return`${t.myModel()} - ${t.mySN()} - ${t.myOS()}`},t.myName=function(){let e=t.myNickname();return app.Utils.isWhiteSpace(e)&&(e=t.myUniqueName()),e},t.myModel=function(){return"Chrome"},t.mySN=function(){return app.Utils.get("deviceSN")},t.myOS=function(){return app.Utils.get("os")},t.myVersion=function(){return app.Utils.getChromeVersion()},t.myNickname=function(){return app.Utils.get("deviceNickname")},e.app=e.app||{},e.app.Device=t}(window);