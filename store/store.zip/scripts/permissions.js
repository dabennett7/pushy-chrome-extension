/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Permissions=function(){"use strict";const s=["tabs"],n=["http://*/*","https://*/*"],e="notSet",t="allowed",i="denied";return{NOT_SET:e,ALLOWED:t,DENIED:i,notSet:function(){return app.Utils.get("permissions")===e},isAllowed:function(){return app.Utils.get("permissions")===t},request:function(){const e=new ChromePromise;return e.permissions.request({permissions:s,origins:n}).then(s=>{return s?(app.Utils.set("permissions",app.Permissions.ALLOWED),Promise.resolve(s)):app.Permissions.remove().then(()=>{return Promise.resolve(!1)})})},contains:function(){const e=new ChromePromise;return e.permissions.contains({permissions:s,origins:n})},remove:function(){app.Utils.set("permissions",app.Permissions.DENIED);const e=new ChromePromise;return app.Permissions.contains().then(t=>{return t?e.permissions.remove({permissions:s,origins:n}).then(s=>{return Promise.resolve(s)}):Promise.resolve(!1)})},injectContentScripts:function(){app.Permissions.isAllowed()&&chrome.windows.getAll({populate:!0},function(s){for(let n=0;n<s.length;n++){const e=s[n];for(let t=0;t<e.tabs.length;t++){const s=e.tabs[t];s.url.match(/(http|https):\/\//gi)&&app.Permissions.injectContentScript(s.id)}}})},injectContentScript:function(s){app.Permissions.isAllowed()&&chrome.tabs.executeScript(s,{file:"scripts/on_copy_cut_content_script.js",allFrames:!0,matchAboutBlank:!0},function(){chrome.runtime.lastError})}}}();