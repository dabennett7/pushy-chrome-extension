/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Fb=function(){"use strict";function e(e){const i={apiKey:"AIzaSyBzqx2gVefRo3tvMFGRFs9gztd081pRgVg",authDomain:"clip-man.firebaseapp.com",databaseURL:"https://clip-man.firebaseio.com",storageBucket:"clip-man.appspot.com",messagingSenderId:"597467211507"};return n().then(()=>{a=firebase.initializeApp(i),o=firebase.auth(),r=firebase.messaging(),r.useServiceWorker(e),r.onTokenRefresh(t)})}function n(){return a?firebase.app().delete():Promise.resolve()}function t(){r.getToken().then(e=>{if(app.Utils.isSignedIn())return app.Reg.register(e)}).catch(e=>{})}const i="Failed to obtain messaging token.\n";let r,o,a=null;return{initialize:function(n){return e(n)},signIn:function(e){return app.SW.initialize().then(()=>{const n=firebase.auth.GoogleAuthProvider.credential(null,e);return o.signInWithCredential(n)})},signOut:function(){return app.SW.unregister().then(()=>{return o.signOut()})},getRegToken:function(){return r.getToken().then(e=>{return e?Promise.resolve(e):Promise.reject(new Error(i))})}}}();