/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Msg=function(){"use strict";function e(e,t){const i=n();return i.act=e,i.m=t,i}function n(){return{[app.Device.MODEL]:app.Device.myModel(),[app.Device.SN]:app.Device.mySN(),[app.Device.OS]:app.Device.myOS(),[app.Device.NICKNAME]:app.Device.myNickname()}}function t(e,n){if(!app.Utils.isSignedIn()||!app.Utils.allowPush())return Promise.resolve();let t;return app.Fb.getRegToken().then(n=>{const p=encodeURIComponent(JSON.stringify(e)),o=app.Utils.get("highPriority");return t=`${i}${n}/${p}/${o}`,app.User.getAuthToken(!0)}).then(e=>{return app.Gae.doPost(t,e,!0)}).then(()=>{return n&&app.Notify.onSend()&&app.Notify.create(app.Notify.NOTIFY_SEND,e),app.GA.event(app.GA.SENT),Promise.resolve()})}const i=`${app.Gae.GAE_ROOT}/messaging/v1/send/`,p="m",o="ping_others",r="respond_to_ping",c="add_our_device",s="remove_our_device",a="Contacting other devices...",u="Device is online",d="New device added",v="Device removed";return{ACTION_MESSAGE:p,ACTION_PING:o,ACTION_PING_RESPONSE:r,ACTION_DEVICE_ADDED:c,ACTION_DEVICE_REMOVED:s,sendClipItem:function(n){if(app.Utils.isWhiteSpace(n.text))return Promise.resolve();let i=n.text;i.length>4096&&(i=i.substring(0,4095));const o=e(p,i);return o.FAV=n.fav?"1":"0",t(o,!0)},sendDeviceAdded:function(){const n=e(c,d);return t(n,!0)},sendDeviceRemoved:function(){const n=e(s,v);return t(n,!0)},sendPing:function(){const n=e(o,a);return t(n,!1)},sendPingResponse:function(n){const i=e(r,u);return i.srcRegId=n,t(i,!1)}}}();