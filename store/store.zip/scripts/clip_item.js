/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
!function(t){"use strict";function e(){i=new Dexie("ClipItemsDB"),i.version(r).stores({clipItems:"&text,date"}),i.clipItems.mapToClass(n)}const n=function(t,e,n,i,r){this.text=t,this.date=e,this.fav=n,this.remote=i,this.device=r};let i;const r=1;n.ERROR_EMPTY_TEXT="Empty text",n.prototype.setDate=function(t){this.date=t},n.prototype.getFav=function(){return this.fav},n.prototype.setFav=function(t){this.fav=t},n.prototype.setRemote=function(t){this.remote=t},n.prototype.save=function(){return app.Utils.isWhiteSpace(this.text)?Promise.reject(new Error(n.ERROR_EMPTY_TEXT)):i.clipItems.put(this)},n.prototype.exists=function(){return i.clipItems.get(this.text).then(t=>{return Promise.resolve(void 0!==t)})},n.add=function(t,e,i,r,o){let s;const p=new n(t,e,i,r,o);return p.exists().then(t=>{return s=t,p.save()}).then(()=>{return chrome.runtime.sendMessage({message:"clipAdded",clipItem:p,updated:s},t=>{}),Promise.resolve(p)})},n.remove=function(t){return i.clipItems.bulkDelete(t)},n.isEmpty=function(){return i.clipItems.count().then(t=>{return Promise.resolve(!t)})},n.loadAll=function(){return i.clipItems.toArray()},n.deleteOld=function(){const t=app.Utils.get("storageDuration"),e=[app.Utils.MILLIS_IN_DAY,7*app.Utils.MILLIS_IN_DAY,30*app.Utils.MILLIS_IN_DAY,365*app.Utils.MILLIS_IN_DAY];if(4===t)return Promise.resolve(!1);{const i=Date.now()-e[t];return n._deleteOlderThan(i)}},n._deleteOlderThan=function(t){return i.clipItems.where("date").below(t).filter(function(t){return!t.fav}).delete().then(t=>{return Promise.resolve(!!t)})},t.addEventListener("load",e),t.app=t.app||{},t.app.ClipItem=n}(window);