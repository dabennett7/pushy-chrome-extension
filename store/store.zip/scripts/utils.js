/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Utils=function(){"use strict";const e=1440,n=864e5;return{MIN_IN_DAY:e,MILLIS_IN_DAY:n,getExtensionName:function(){return`chrome-extension://${chrome.runtime.id}`},getVersion:function(){const e=chrome.runtime.getManifest();return e.version},getChromeVersion:function(){const e=navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);return!!e&&parseInt(e[2],10)},getFullChromeVersion:function(){const e=navigator.userAgent;return e?e:"Unknown"},getPlatformOS:function(){const e=new ChromePromise;return e.runtime.getPlatformInfo().then(e=>{let n="Unknown";const t=e.os;switch(t){case"win":n="MS Windows";break;case"mac":n="Mac";break;case"android":n="Android";break;case"cros":n="Chrome OS";break;case"linux":n="Linux";break;case"openbsd":n="OpenBSD"}return Promise.resolve(n)})},get:function(e){let n=localStorage.getItem(e);return null!==n&&(n=JSON.parse(n)),n},set:function(e,n){null!==n?localStorage.setItem(e,JSON.stringify(n)):localStorage.removeItem(e)},isMonitorClipboard:function(){return app.Utils.get("monitorClipboard")},allowPush:function(){return app.Utils.get("allowPush")},isAutoSend:function(){return app.Utils.get("autoSend")},allowReceive:function(){return app.Utils.get("allowReceive")},isSignedIn:function(){return this.get("signedIn")},isRegistered:function(){return this.get("registered")},notRegistered:function(){return!this.isRegistered()},isWhiteSpace:function(e){return!e||0===e.length||/^\s*$/.test(e)},getRelativeTime:function(e){return moment(e).fromNow()+", "+moment(e).format("h:mm a")},randomString:function(e){const n="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";!!e||(e=8),e||(e=8);let t="";for(let r=0;r<e;r++)t+=n.charAt(Math.floor(Math.random()*n.length));return t}}}(window);