/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Utils=function(){"use strict";const e=1440,t=864e5;return{MIN_IN_DAY:e,MILLIS_IN_DAY:t,getExtensionName:function(){return`chrome-extension://${chrome.runtime.id}`},getVersion:function(){const e=chrome.runtime.getManifest();return e.version},getChromeVersion:function(){const e=navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);return!!e&&parseInt(e[2],10)},getFullChromeVersion:function(){const e=navigator.userAgent;return e?e:"Unknown"},getPlatformOS:function(){const e=new ChromePromise;return e.runtime.getPlatformInfo().then(e=>{let t="Unknown";const n=e.os;switch(n){case"win":t="MS Windows";break;case"mac":t="Mac";break;case"android":t="Android";break;case"cros":t="Chrome OS";break;case"linux":t="Linux";break;case"openbsd":t="OpenBSD"}return Promise.resolve(t)})},get:function(e){let t=localStorage.getItem(e);return null!==t&&(t=JSON.parse(t)),t},set:function(e,t){null!==t?localStorage.setItem(e,JSON.stringify(t)):localStorage.removeItem(e)},getInt:function(e){return parseInt(localStorage.getItem(e),10)},isMonitorClipboard:function(){return app.Utils.get("monitorClipboard")},allowPush:function(){return app.Utils.get("allowPush")},isAutoSend:function(){return app.Utils.get("autoSend")},allowReceive:function(){return app.Utils.get("allowReceive")},isSignedIn:function(){return this.get("signedIn")},isRegistered:function(){return this.get("registered")},notRegistered:function(){return!this.isRegistered()},setBadgeText:function(){let e="";app.Utils.isSignedIn()&&app.Utils.allowPush()&&(e="SEND"),chrome.browserAction.setBadgeText({text:e})},isWhiteSpace:function(e){return!e||0===e.length||/^\s*$/.test(e)},getRelativeTime:function(e){return`${moment(e).fromNow()}, `+`${moment(e).format("h:mm a")}`},randomString:function(e){const t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";!!e||(e=8),e||(e=8);let n="";for(let r=0;r<e;r++)n+=t.charAt(Math.floor(Math.random()*t.length));return n}}}(window);