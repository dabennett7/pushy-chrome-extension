/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.ReceiveMsg=function(){"use strict";function e(e){return new app.Device(e.dM,e.dSN,e.dOS,e.dN,Date.now())}function p(e){const p=decodeURI(e.url),s=/https:\/\/pushy-clipboard\.github\.io\/\?(.*)/;let t;const c=p.match(s);if(c&&c.length>1&&(t=c[1]),t){const e=JSON.parse(t);if(e)for(let p=0;p<e.length;p++)!function(p){setTimeout(function(){app.ReceiveMsg.process(e[p])},a)}(p)}return{cancel:!0}}const a=500;return chrome.webRequest.onBeforeRequest.addListener(p,{urls:["https://pushy-clipboard.github.io/*"]},["blocking"]),{process:function(p){const a=e(p);if(app.Utils.isSignedIn()&&!a.isMe())if(app.GA.event(app.GA.RECEIVED),p.act===app.Msg.ACTION_MESSAGE){app.Devices.add(a);const e="1"===p.fav;app.ClipItem.add(p.m,Date.now(),e,!0,a.getName()).catch(e=>{}),app.CB.copyToClipboard(p.m)}else p.act===app.Msg.ACTION_PING?(app.Devices.add(a),app.Msg.sendPingResponse(p.srcRegId).catch(e=>{app.Gae.sendMessageFailed(e)})):p.act===app.Msg.ACTION_PING_RESPONSE?app.Devices.add(a):p.act===app.Msg.ACTION_DEVICE_ADDED?app.Devices.add(a):p.act===app.Msg.ACTION_DEVICE_REMOVED&&app.Devices.remove(a)}}}();