/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
!function(){"use strict";function t(t){let n;return n=t.dN?t.dN:`${t.dM} - ${t.dSN} - ${t.dOS}`}function n(t){let n=l;return"m"===t.act&&(n=f),n}function e(t){let n=h;return"m"===t.act?n=u:"remove_our_device"===t.act&&(n=m),n}function i(t){return d=`${a}${JSON.stringify(t)}`,fetch(d,{method:"GET"})}function o(o){const c=o.data.json(),a=c.data;a.m=decodeURIComponent(a.m);const s=n(a),r={requireInteraction:s===f,body:a.m,icon:e(a),tag:s,timestamp:Date.now()};s===f&&(r.actions=[{action:"search",title:"Search web",icon:g}]);let d=`From ${t(a)}`;i(a).catch(()=>{});const l=clients.matchAll({includeUncontrolled:!0,type:"window"}).then(t=>{for(let n=0;n<t.length;n++)if(t[n].focused===!0){r.requireInteraction=!1;break}return self.registration.getNotifications({tag:s}).then(t=>{return t.length>0?(r.renotify=!0,r.data=t[0].data+1,d=`${r.data} new items
${d}`):r.data=1,self.registration.showNotification(d,r)})});o.waitUntil(l)}function c(t){let n=r;"search"===t.action&&(n=s+encodeURIComponent(t.notification.body)),t.notification.close();const e=clients.matchAll({includeUncontrolled:!0,type:"window"}).then(t=>{for(let e=0;e<t.length;e++){const i=t[e];if(i.url===n&&"focus"in i)return i.focus()}if(clients.openWindow)return clients.openWindow(n)});t.waitUntil(e)}const a="http://www.anyoldthing.com/?",s="https://www.google.com/search?q=",r="chrome-extension://jemdfhaheennfkehopbpkephjlednffd/html/main.html";let d;const f="tag-message",l="tag-device",u="../images/ic_remote_copy.png",h="../images/ic_add_device.png",m="../images/ic_remove_device.png",g="../images/search-web.png";self.addEventListener("install",()=>{self.skipWaiting()}),self.addEventListener("activate",()=>{clients.claim()}),self.addEventListener("push",o),self.addEventListener("notificationclick",c)}();