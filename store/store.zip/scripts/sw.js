/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
!function(){"use strict";function t(t){let n;return n=t.dN?t.dN:`${t.dM} - ${t.dSN} - ${t.dOS}`}function n(t){let n=u;return"m"===t.act&&(n=l),n}function e(t){let n="";return"m"===t.act?n=h:"remove_our_device"===t.act?n=m:"add_our_device"!==t.act&&"respond_to_ping"!==t.act||(n=g),n}function i(t){return w=[],v=[],f=s+JSON.stringify(t),fetch(f,{method:"GET"}).then(()=>{return Promise.resolve()}).catch(t=>{return Promise.reject(t)})}function o(o){const c=o.data.json(),a=c.data;a.m=decodeURIComponent(a.m);const s=n(a),r=e(a),d={requireInteraction:!0,body:a.m,icon:r,tag:s,timestamp:Date.now()};let f=[a],h=`From ${t(a)}`;const g=clients.matchAll({includeUncontrolled:!0}).then(t=>{let n=!0;for(let e=0;e<t.length;e++)if(t[e].focused===!0){n=!1;break}return n&&""!==r?self.registration.getNotifications({tag:s}).then(t=>{return s===l&&(d.actions=[{action:"search",title:"Search web",icon:p}]),t.length>0?(d.renotify=!0,f=t[0].data,f.push(a),h=`${f.length} new items
${h}`,d.data=f):s===l?(w.push(a),w.length>1&&(h+=`
${w.length} new items`),d.data=JSON.parse(JSON.stringify(w))):s===u&&(v.push(a),v.length>1&&(h+=`
${v.length} new items`),d.data=JSON.parse(JSON.stringify(v))),self.registration.showNotification(h,d)}):i(f).catch(()=>{})});o.waitUntil(g)}function c(t){let n=d;"search"===t.action&&(n=r+encodeURIComponent(t.notification.body)),t.notification.close(),""!==t.notification.icon&&i(t.notification.data).catch(function(){});const e=clients.matchAll({includeUncontrolled:!0,type:"window"}).then(t=>{for(let e=0;e<t.length;e++){const i=t[e];if(i.url===n&&"focus"in i)return i.focus()}if(clients.openWindow)return clients.openWindow(n)});t.waitUntil(e)}function a(t){""!==t.notification.icon&&t.waitUntil(i(t.notification.data).catch(()=>{}))}const s="http://www.anyoldthing.com/?",r="https://www.google.com/search?q=",d="chrome-extension://dnginconopbhmnapbipjoohbgknhkdoh/html/main.html";let f;const l="tag-message",u="tag-device",h="../images/ic_remote_copy.png",g="../images/ic_add_device.png",m="../images/ic_remove_device.png",p="../images/search-web.png";let w=[],v=[];self.addEventListener("install",()=>{self.skipWaiting()}),self.addEventListener("activate",()=>{clients.claim()}),self.addEventListener("push",o),self.addEventListener("notificationclick",c),self.addEventListener("notificationclose",a)}();