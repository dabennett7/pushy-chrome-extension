/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
!function(){"use strict";function t(t){let n;return n=t.dN?t.dN:`${t.dM} - ${t.dSN} - ${t.dOS}`}function n(t){let n=u;return"m"===t.act&&(n=d),n}function e(t){let n=g;return"m"===t.act?n=h:"remove_our_device"===t.act&&(n=m),n}function i(t){return t instanceof Array?o(t).catch(()=>{}):Promise.resolve()}function o(t){w=[];const n=s+JSON.stringify(t);return fetch(n,{method:"GET"})}function c(c){const a=c.data.json(),r=a.data;r.m=decodeURIComponent(r.m);const s=n(r),f={requireInteraction:s===d,body:r.m,icon:e(r),tag:s,timestamp:Date.now(),data:null};s===d&&(f.actions=[{action:"search",title:"Search web",icon:p}]);let l=`From ${t(r)}`;const u=clients.matchAll({includeUncontrolled:!0,type:"window"}).then(t=>{for(let n=0;n<t.length;n++)if(t[n].focused===!0)return o([r]).catch(()=>{});return self.registration.getNotifications({tag:s}).then(t=>{if(t.length>0){f.renotify=!0;const n=t[0].data;if(n instanceof Array)return n.push(r),i(n).then(()=>{throw l+=`
${n.length} new items`,f.data=n.length,new Error("fetch failed")});f.data=t[0].data+1,l=`${f.data} new items
${l}`}else f.data=1;return o([r])}).then(()=>{return s===d&&(w.push(r),w.length>1&&(l+=`
${w.length} new items`),f.data=JSON.parse(JSON.stringify(w))),self.registration.showNotification(l,f)}).catch(()=>{return self.registration.showNotification(l,f)})});c.waitUntil(u)}function a(t){let n=l;"search"===t.action&&(n=f+encodeURIComponent(t.notification.body)),t.notification.close();const e=clients.matchAll({includeUncontrolled:!0,type:"window"}).then(e=>{return i(t.notification.data).then(()=>{for(let t=0;t<e.length;t++){const i=e[t];if(i.url===n&&"focus"in i)return i.focus()}if(clients.openWindow)return clients.openWindow(n)}).catch(()=>{})});t.waitUntil(e)}function r(t){t.waitUntil(i(t.notification.data).catch(()=>{}))}const s="https://pushy-clipboard.github.io/?",f="https://www.google.com/search?q=",l="chrome-extension://jemdfhaheennfkehopbpkephjlednffd/html/main.html",d="tag-message",u="tag-device",h="../images/ic_remote_copy.png",g="../images/ic_add_device.png",m="../images/ic_remove_device.png",p="../images/search-web.png";let w=[];self.addEventListener("install",t=>{t.waitUntil(self.skipWaiting())}),self.addEventListener("activate",t=>{t.waitUntil(self.clients.claim())}),self.addEventListener("push",c),self.addEventListener("notificationclick",a),self.addEventListener("notificationclose",r)}();