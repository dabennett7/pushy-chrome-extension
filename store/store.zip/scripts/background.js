/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
!function(){"use strict";function e(e){"install"===e.reason?(app.Utils.getPlatformOS().then(e=>{app.Utils.set("os",e)}),s(),app.Notify.showMainTab()):"update"===e.reason&&(p(),c().then(()=>{return app.SW.update()}).catch(e=>{})),app.Utils.setBadgeText(),app.Alarm.updateAlarms(),app.Permissions.injectContentScripts()}function t(){app.Alarm.updateAlarms(),app.Alarm.deleteOldClipItems(),c().catch(e=>{}),app.Utils.setBadgeText()}function n(){const e=app.CB.getTextFromClipboard();app.Utils.isWhiteSpace(e)||app.ClipItem.add(e,Date.now(),!1,!1,app.Device.myName()).then(e=>{app.Msg.sendClipItem(e).catch(e=>{app.Gae.sendMessageFailed(e)})}).catch(e=>{})}function i(e){app.Permissions.injectContentScript(e)}function a(e){"allowPush"!==e.key&&"signedIn"!==e.key||app.Utils.setBadgeText()}function o(){Object.keys(l).forEach(function(e){null===app.Utils.get(e)&&app.Utils.set(e,l[e])})}function s(){o();const e=new app.ClipItem(d,Date.now(),!0,!1,app.Device.myName());e.save(),app.User.setInfo().catch(e=>{})}function p(){const e=app.Utils.getInt("version");e<2&&(app.Utils.set("version",r),localStorage.removeItem("lastEmail"),localStorage.removeItem("lastUid")),o()}function c(){return app.Utils.isSignedIn()?app.SW.initialize().catch(e=>{}):Promise.resolve()}const r=2,l={version:r,monitorClipboard:!0,allowPush:!0,autoSend:!0,permissions:"notSet",allowReceive:!0,deviceSN:app.Utils.randomString(8),deviceNickname:"",storageDuration:2,notify:!0,notifyOnSend:!1,notifyOnReceive:!0,highPriority:!0,devices:{},signedIn:!1,needsCleanup:!1,email:"",uid:"",photoURL:"",registered:!1},d=`A clipboard manager with push notifications.

Please signin from the "Manage Account" page to share with your other devices.

You can click on the toolbar icon at any time to send the current contents of the clipboard to all your other devices.

Information you copy in most Chrome pages will automatically be sent if you have enabled that in "Settings".

You can display this page by right clicking on the toolbar icon and selecting "Options".

It is a good idea to go to the "Settings" page and enter a nickname for this device.`;chrome.runtime.onInstalled.addListener(e),chrome.runtime.onStartup.addListener(t),chrome.browserAction.onClicked.addListener(n),chrome.tabs.onUpdated.addListener(i),addEventListener("storage",a,!1)}();