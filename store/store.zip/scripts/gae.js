/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Gae=function(){"use strict";function t(t,n){return app.User.removeCachedAuthToken(n).then(()=>{return app.User.getAuthToken(!1)}).then(n=>{return app.Gae.doPost(t,n,!1)})}const n="https://clip-man.appspot.com/_ah/api",e=n,r="Authorization",o="Content-Type",s="Accept",u="application/json";return{GAE_ROOT:e,doPost:function(n,e,a=false){function i(n,r){return fetch(n,r).then(o=>{if(o.ok)return o.json();if(a&&401===o.status)return t(n,e);if(f<4&&o.status>=500&&o.status<600){f++;const t=1e3*(Math.pow(2,f)-1);return new Promise(()=>{setTimeout(()=>{return i(n,r)},t)})}throw new Error("status: "+o.status,"\nreason: "+o.statusText)}).then(r=>{if(r.success)return Promise.resolve();if(a&&"Unauthorized user"===r.reason)return t(n,e);throw new Error(r.reason)})}const c={[r]:`Bearer ${e}`,[o]:u,[s]:u},p={method:"POST",headers:c};let f=0;return i(n,p)},getJSON:function(t){let n;try{n=JSON.parse(t)}catch(t){n=null}return n}}}();