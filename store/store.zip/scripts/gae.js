/*
 *
 * Copyright 2016 Michael A Updike
 *
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
window.app=window.app||{},app.Gae=function(){"use strict";function t(t,e){return app.User.removeCachedAuthToken(e).then(()=>{return app.User.getAuthToken(!1)}).then(e=>{return app.Gae.doPost(t,e,!1)})}const e="https://clip-man.appspot.com/_ah/api",n=e,r="Authorization",o="Content-Type",s="Accept",u="application/json";return{GAE_ROOT:n,doPost:function(e,n,a=false){function i(e,r){return fetch(e,r).then(o=>{if(o.ok)return o.json();if(a&&401===o.status)return t(e,n);if(f<4&&o.status>=500&&o.status<600){f++;const t=1e3*(Math.pow(2,f)-1);return new Promise(()=>{setTimeout(()=>{return i(e,r)},t)})}throw new Error("status: "+o.status,"\nreason: "+o.statusText)}).then(r=>{if(r.success)return Promise.resolve();if(a&&"Unauthorized user"===r.reason)return t(e,n);throw new Error(r.reason)})}const c={[r]:`Bearer ${n}`,[o]:u,[s]:u},p={method:"POST",headers:c};let f=0;return i(e,p)},getJSON:function(t){let e;try{e=JSON.parse(t)}catch(t){e=null}return e},sendMessageFailed:function(t){chrome.runtime.sendMessage({message:"sendMessageFailed",error:t.toString()},()=>{})}}}();